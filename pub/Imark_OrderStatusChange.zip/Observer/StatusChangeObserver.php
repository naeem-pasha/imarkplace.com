<?php
namespace Imark\OrderStatusChange\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class StatusChangeObserver implements ObserverInterface
{
    public function execute(Observer $observer)
    {
        // Additional observer logic (if needed)
    }
}
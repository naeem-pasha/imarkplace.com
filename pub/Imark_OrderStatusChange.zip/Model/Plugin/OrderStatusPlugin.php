<?php
namespace Imark\OrderStatusChange\Model\Plugin;

use Magento\Sales\Model\Order;

class OrderStatusPlugin
{
    public function beforeSetStatus(Order $subject, $status)
    {
        if ($status === 'processing') {
            $subject->setCanSendNewEmailFlag(true); // Allows bypassing restrictions
        }
        return [$status];
    }
}
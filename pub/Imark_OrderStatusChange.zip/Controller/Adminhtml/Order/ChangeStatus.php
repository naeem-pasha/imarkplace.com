<?php
namespace Imark\OrderStatusChange\Controller\Adminhtml\Order;

use Magento\Backend\App\Action;
use Magento\Sales\Api\OrderRepositoryInterface;

class ChangeStatus extends Action
{
    protected $orderRepository;

    public function __construct(
        Action\Context $context,
        OrderRepositoryInterface $orderRepository
    ) {
        $this->orderRepository = $orderRepository;
        parent::__construct($context);
    }

    public function execute()
    {
        $orderId = $this->getRequest()->getParam('order_id');
        $order = $this->orderRepository->get($orderId);

        if ($order && $order->getStatus() === 'pending') {
            $order->setState(\Magento\Sales\Model\Order::STATE_PROCESSING);
            $order->setStatus(\Magento\Sales\Model\Order::STATE_PROCESSING);
            $this->orderRepository->save($order);
            $this->messageManager->addSuccessMessage('Order status changed to Processing.');
        } else {
            $this->messageManager->addErrorMessage('Unable to change order status.');
        }

        $this->_redirect('sales/order/view', ['order_id' => $orderId]);
    }
}
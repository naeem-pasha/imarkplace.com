define([], function () {
    'use strict';
});
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            fixCaptchaAfterAjax: 'Magento_Captcha/js/captcha-fix'
        }
    }
};

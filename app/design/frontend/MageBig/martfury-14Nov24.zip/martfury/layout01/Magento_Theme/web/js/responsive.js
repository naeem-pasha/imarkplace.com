// Magento 2.4.1 no longer use this
define([
], function () {
    'use strict';
});

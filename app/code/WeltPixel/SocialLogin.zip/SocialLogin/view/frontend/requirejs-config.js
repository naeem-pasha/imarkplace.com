var config = {
    map: {
        '*': {
            'sociallogin': 'WeltPixel_SocialLogin/js/sociallogin',
            'slReferer': 'WeltPixel_SocialLogin/js/slreferer'
        }
    }
};
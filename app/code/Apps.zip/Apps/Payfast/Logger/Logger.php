<?php
namespace Apps\Payfast\Logger;

class Logger extends \Monolog\Logger
{
}